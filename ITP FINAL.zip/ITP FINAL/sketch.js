/*

The Game Project


*/


var gameChar_x;
var gameChar_y;
var floorPos_y;

var scrollPos;
var gameChar_world_x;

var isLeft;
var isRight;
var isFalling;
var isPlummeting;
var isJump;

var collectables;
var canyon;
var collectable;
var trees_x;
var treePos_y;
var mountain_x;
var mountain_y;
var clouds;
var heart;

var game_score;
var flagpole;
var lives;
var isDead;
var flag;

var backgroundpic;
var enemies;
var platforms;
var squidwardHouse_x;
var squidwardHouse_y;
var spongebobHouse_x;
var spongebobHouse_y;
var patrickHouse_x;
var patrickHouse_y;

var cameraPosX;

var emit;


var jumpSound;
var hitSound;
var collectableSound;
var levelCompleteSound;
var fallingSound;


function startGame(){
    gameChar_x = width/2;
	gameChar_y = floorPos_y;
    
    // variable to control the background scrolling
    scrollPos = 0;
    
    //set isDead variable to false
    isDead = false;
    
    gameChar_world_x = gameChar_x - scrollPos;
    
    //set variables for whether character is moving left, right, falling, plummeting and jumping to false
    isLeft = false;
    isRight = false;
    isFalling = false;
    isPlummeting = false;
    isJump = false;
    
    //set x positions of trees to be drawn
    trees_x = [-1962,-1462,-962,-462,-58,420,920,1420,1920];
    //set y positions of trees to be drawn
    treePos_y = height/2;
    
    //set x positions of where squidward house will be drawn
    squidwardHouse_x = -650;
    //set y positions of where squidward house will be drawn
    squidwardHouse_y = floorPos_y;
    
    //set x positions of where spongebob house will be drawn
    spongebobHouse_x = 1225;
    //set y positions of where spongebob house will be drawn
    spongebobHouse_y = floorPos_y;
    
    //set x positions of where patrick house will be drawn
    patrickHouse_x = -1500;
    //set y positions of where patrick house will be drawn
    patrickHouse_y = floorPos_y;
    
    

    //set x and y positions of where clouds will be drawn
    clouds = [
        {x_pos: -1150, y_pos: 30},
        {x_pos: -630, y_pos: 10},
        {x_pos: -230, y_pos: 0},
        {x_pos: 400, y_pos: 40},
        {x_pos: 900, y_pos: 30},
        {x_pos: 1550, y_pos: 10},
    ];
    
     
    //set x positions of where mountains will be drawn
    mountain_x = [-1500, -1000,-500,0,500,1000, 1500];
    //set y positions of where mountains house will be drawn
    mountain_y = 0;
    
    cameraPosX = 0;
    
    //set x positions of where scanyons will be drawn
    canyons = [
        {x_pos: 0, width: 100},
        {x_pos: 750, width: 100},
        {x_pos: 1600, width: 100},
        {x_pos: -650, width: 100},
        {x_pos: -1300, width: 100},

    ];
    

    //set x, y positions  of where collectables will be drawn, size and whether collectable has been collected
    collectables = [
        {x_pos: 100, y_pos: 100, size: 28, isFound: false},
        {x_pos: 750, y_pos: 100, size: 28, isFound: false},
        {x_pos: 1350, y_pos: 100, size: 28, isFound: false},
        {x_pos: 1870, y_pos: 80, size: 28, isFound: false},
        {x_pos: -372, y_pos: 75, size: 28, isFound: false},
        {x_pos: -800, y_pos: 100, size: 28, isFound: false},
        {x_pos: -1400, y_pos: 100, size: 28, isFound: false},
        {x_pos: -1600, y_pos: 100, size: 28, isFound: false},

    ];
    
    //set x position of where hearts showing number of lives will be drawn
    heart = [70,110,150];
    
    
    //set flagpole is reached to false and x position of flagpole
    flagpole = {isReached: false, x_pos: 2300};
    
    //empty array for platforms
    platforms = [];
    
    //create platforms
    platforms.push(createPlatforms(100,floorPos_y-50 ,20));
    platforms.push(createPlatforms(800,floorPos_y-100 ,20));
    platforms.push(createPlatforms(1500,floorPos_y-50 ,20));
    platforms.push(createPlatforms(1900,floorPos_y-40 ,20));
    platforms.push(createPlatforms(-800,floorPos_y-80 ,20));
    platforms.push(createPlatforms(-1000,floorPos_y-70 ,20));
    platforms.push(createPlatforms(-1400,floorPos_y-60 ,20));
    
    //empty array for enemies
    enemies = [];
    
    //create enemies
    enemies.push(new Enemy(0,floorPos_y - 10, 100));
    enemies.push(new Enemy(800,floorPos_y - 10, 100));
    enemies.push(new Enemy(1500,floorPos_y - 10, 100));
    enemies.push(new Enemy(-800,floorPos_y - 10, 100));
    enemies.push(new Enemy(-1800,floorPos_y - 10, 100));
    
    
}


function preload()
{
    //load image for flag
	flag = loadImage("flag.jpg");
    //load image for background
    backgroundpic = loadImage("background-2.jpg");
    
    //set sound formats
    soundFormats('mp3','wav');
    
    //load sound for when character jumps
    jumpSound = loadSound('assets/jump.wav');
    //set volume for sound when character jumps
    jumpSound.setVolume(0.1);
    
    //load sound for when character dies to enemy
    hitSound = loadSound('assets/hit.wav')
    //set volume for sound of when character dies to enemy
    hitSound.setVolume(0.1);
    
    //load sound for when character collects the collectable
    collectableSound = loadSound('assets/collected.wav');
    //set volume of sound for when character collects the collectable 
    collectableSound.setVolume(0.1);
    
    //load sound for when character reaches the flag
    levelCompleteSound = loadSound('assets/level-complete.wav');
    //set volume of sound for when character reaches the flag
    levelCompleteSound.setVolume(0.1);
    
    //load sound for when character falls into canyon
    fallingSound = loadSound('assets/falling.wav');
    //set volume of sound for when character falls into canyon
    fallingSound.setVolume(0.1);
    
}



function setup()
{
    //create canvas
	createCanvas(1024, 576);
	floorPos_y = height * 3/4;
    //start the game
    startGame();
    //set starting amount of lives to 3
    lives = 3;
    //set starting game score to 0
    game_score = 0;
    //create new emitter to produce bubbles
    emit = new Emitter(width/2, height-100, 0, -1, 10, color(203, 239, 255,100));
    emit.startEmitter(200,10000000);

    
}


function draw()
{

	///////////DRAWING CODE//////////
    
    //side-scrolling
    cameraPosX = gameChar_x - width/2;
    
	//set background image
    background(backgroundpic);
    
    //draw bubbles
    emit.updateParticles();


    //draw the sand ground
	noStroke();
	fill(219, 229, 195);
	rect(0, floorPos_y, width, height - floorPos_y); 
    
    push();
    translate(-cameraPosX, 0);
    
    
    
    
    
    
    //draw clouds
    drawClouds();
    
    
    //draw mountains
    drawMountains();
    
    //draw trees
    drawTrees();
    
    //draw squidward house
    drawSquidwardHouse();
    
    //draw spongebob house
    drawSpongebobHouse();
    
    //draw patrick house
    drawPatrickHouse();
    
    //drawCollectable
    for(var i = 0; i < collectables.length; i++){
        if(!collectables[i].isFound)
            {
                drawCollectable(collectables[i]);
                checkCollectable(collectables[i]);
            }
        
    }
    
    
    //draw canyons
        
    for(var i = 0; i < canyons.length; i++){
        drawCanyon(canyons[i]);
        checkCanyon(canyons[i]);

    }
    
    //draw platform
    for(var i = 0; i < platforms.length; i++){
        platforms[i].draw();
    }
    
 
    
    

	//code for when character jump facing left
	if(isLeft && isFalling)
	{
		
        //eye
        fill(255);
        stroke(0);
        strokeWeight(0.5);
        ellipse(gameChar_x-10,gameChar_y-58,5,8);
        fill(0,153,255);
        ellipse(gameChar_x-10,gameChar_y-58,3,3);
        fill(0);
        ellipse(gameChar_x-10,gameChar_y-58,1.5,1.5);


        //body
        fill(255,253,77);
        stroke(0);
        strokeWeight(0.5);  

        //nose
        ellipse(gameChar_x-11,gameChar_y-50,10,3);

        rect(gameChar_x-10,gameChar_y-67,20,30);

        //shirt
        fill(255);
        stroke(0);
        strokeWeight(0.5);
        rect(gameChar_x-10,gameChar_y-37,20,5);

        //pants
        fill(115,80,50);
        rect(gameChar_x-10,gameChar_y-32,20,8);
        beginShape();
        vertex(gameChar_x-2,gameChar_y-24);
        vertex(gameChar_x-5,gameChar_y-24);
        vertex(gameChar_x-7,gameChar_y-21);
        vertex(gameChar_x-2,gameChar_y-21);

        endShape(CLOSE);
        rect(gameChar_x-2,gameChar_y-24,6,3);
        fill(0);
        rect(gameChar_x-3,gameChar_y-30,6,2);

        //legs
        fill(255,253,77);
        rect(gameChar_x-1,gameChar_y-21,4,8);
        rect(gameChar_x+3,gameChar_y-18,5,4);
        beginShape();
        vertex(gameChar_x-2,gameChar_y-21);
        vertex(gameChar_x-6,gameChar_y-21);
        vertex(gameChar_x-7,gameChar_y-12);
        vertex(gameChar_x+5,gameChar_y-13);
        vertex(gameChar_x+5,gameChar_y-17);
        vertex(gameChar_x-3,gameChar_y-16);
        vertex(gameChar_x-2,gameChar_y-21);
        endShape(CLOSE);



        //socks
        fill(255);
        rect(gameChar_x+1,gameChar_y-17,4,4);

        rect(gameChar_x+8,gameChar_y-18,4,4);

        //shoe
        fill(0);
        rect(gameChar_x+5.5,gameChar_y-17,4,4);
        ellipse(gameChar_x+7.5,gameChar_y-11,3.5,3.5);
        rect(gameChar_x+13,gameChar_y-18,4,4);
        ellipse(gameChar_x+15.5,gameChar_y-12,3.5,3.5);

        //sleeve
        fill(255);
        arc(gameChar_x,gameChar_y-34,5,10,PI,TWO_PI,PIE);

        //arm
        fill(255,253,77);
        beginShape();
        vertex(gameChar_x-1.5,gameChar_y-34);
        vertex(gameChar_x-2,gameChar_y-32);
        vertex(gameChar_x-5,gameChar_y-33);
        vertex(gameChar_x-5,gameChar_y-31);
        vertex(gameChar_x,gameChar_y-29);
        vertex(gameChar_x+1,gameChar_y-34);
        endShape(CLOSE);
        ellipse(gameChar_x-6,gameChar_y-32,3,3);

        fill(163, 157, 129);
        noStroke();
        ellipse(gameChar_x-3,gameChar_y-58,7,6);
        ellipse(gameChar_x+4,gameChar_y-54,3,3);
        ellipse(gameChar_x-3,gameChar_y-47,7,6);
        ellipse(gameChar_x+4,gameChar_y-43,3,3);
        

	}
    //code for when character jump facing right
	else if(isRight && isFalling)
	{
        fill(255);
        stroke(0);
        strokeWeight(0.5);
        ellipse(gameChar_x+10,gameChar_y-58,5,8);
        fill(0,153,255);
        ellipse(gameChar_x+10,gameChar_y-58,3,3);
        fill(0);
        ellipse(gameChar_x+10,gameChar_y-58,1.5,1.5);


        //body
        fill(255,253,77);
        stroke(0);
        strokeWeight(0.5);  

        //nose
        ellipse(gameChar_x+11,gameChar_y-50,10,3);

        rect(gameChar_x-10,gameChar_y-67,20,30);



        //pants
        fill(115,80,50);
        rect(gameChar_x-10,gameChar_y-32,20,8);
        beginShape();
        vertex(gameChar_x+2,gameChar_y-24);
        vertex(gameChar_x+5,gameChar_y-24);
        vertex(gameChar_x+7,gameChar_y-21);
        vertex(gameChar_x+2,gameChar_y-21);
        endShape(CLOSE);
        rect(gameChar_x-4,gameChar_y-24,6,3);
        fill(0);
        rect(gameChar_x-3,gameChar_y-30,6,2);

        //shirt
        fill(255);
        stroke(0);
        strokeWeight(0.5);
        rect(gameChar_x-10,gameChar_y-37,20,5);

        //legs
        fill(255,253,77);
        rect(gameChar_x-3,gameChar_y-21,4,8);
        rect(gameChar_x-9,gameChar_y-18,5,4);
        beginShape();
        vertex(gameChar_x+2,gameChar_y-21);
        vertex(gameChar_x+6,gameChar_y-21);
        vertex(gameChar_x+7,gameChar_y-12);
        vertex(gameChar_x-5,gameChar_y-13);
        vertex(gameChar_x-5,gameChar_y-17);
        vertex(gameChar_x+3,gameChar_y-16);
        vertex(gameChar_x+2,gameChar_y-21);
        endShape(CLOSE);



        //socks
        fill(255);
        rect(gameChar_x-3.5,gameChar_y-17,4,4);

        rect(gameChar_x-11,gameChar_y-18,4,4);


        //shoe
        fill(0);
        rect(gameChar_x-7.5,gameChar_y-17,4,4);
        ellipse(gameChar_x-5.5,gameChar_y-11,3.5,3.5);
        rect(gameChar_x-16,gameChar_y-18,4,4);
        ellipse(gameChar_x-14.5,gameChar_y-12,3.5,3.5);


        //sleeve
        fill(255);
        arc(gameChar_x,gameChar_y-34,5,10,PI,TWO_PI,PIE);


        //arm
        fill(255,253,77);
        beginShape();
        vertex(gameChar_x-1.5,gameChar_y-34);
        vertex(gameChar_x-1,gameChar_y-29);
        vertex(gameChar_x+5,gameChar_y-31);
        vertex(gameChar_x+5,gameChar_y-33);
        vertex(gameChar_x+1,gameChar_y-32);
        vertex(gameChar_x+1,gameChar_y-34);
        endShape(CLOSE);

        fill(163, 157, 129);
        noStroke();
        ellipse(gameChar_x+3,gameChar_y-58,7,6);
        ellipse(gameChar_x-4,gameChar_y-54,3,3);
        ellipse(gameChar_x+3,gameChar_y-47,7,6);
        ellipse(gameChar_x-4,gameChar_y-43,3,3);


	}
    //code for when character walking left
	else if(isLeft)
	{
        //eye
        fill(255);
        stroke(0);
        strokeWeight(0.5);
        ellipse(gameChar_x-10,gameChar_y-58,5,8);
        fill(0,153,255);
        ellipse(gameChar_x-10,gameChar_y-58,3,3);
        fill(0);
        ellipse(gameChar_x-10,gameChar_y-58,1.5,1.5);


        //body
        fill(255,253,77);
        stroke(0);
        strokeWeight(0.5);  

        //nose
        ellipse(gameChar_x-11,gameChar_y-50,10,3);

        rect(gameChar_x-10,gameChar_y-67,20,30);

        //shirt
        fill(255);
        stroke(0);
        strokeWeight(0.5);
        rect(gameChar_x-10,gameChar_y-37,20,5);

        //pants
        fill(115,80,50);
        rect(gameChar_x-10,gameChar_y-32,20,8);
        beginShape();
        vertex(gameChar_x-2,gameChar_y-24);
        vertex(gameChar_x-5,gameChar_y-24);
        vertex(gameChar_x-7,gameChar_y-21);
        vertex(gameChar_x-2,gameChar_y-21);

        endShape(CLOSE);
        rect(gameChar_x-2,gameChar_y-24,6,3);
        fill(0);
        rect(gameChar_x-3,gameChar_y-30,6,2);

        //legs
        fill(255,253,77);
        rect(gameChar_x-1,gameChar_y-21,4,8);
        beginShape();
        vertex(gameChar_x-2,gameChar_y-21);
        vertex(gameChar_x-5,gameChar_y-13);
        vertex(gameChar_x-9,gameChar_y-15);
        vertex(gameChar_x-6,gameChar_y-21);
        endShape(CLOSE);



        //socks
        fill(255);
        rect(gameChar_x-1,gameChar_y-13,4,4);
        beginShape();
        vertex(gameChar_x-5,gameChar_y-13);
        vertex(gameChar_x-7,gameChar_y-9);
        vertex(gameChar_x-11,gameChar_y-11);
        vertex(gameChar_x-9,gameChar_y-15);
        endShape(CLOSE);

        //shoe
        fill(0);
        rect(gameChar_x-1,gameChar_y-9,4,4);
        ellipse(gameChar_x-2.5,gameChar_y-7,3.5,3.5);

        beginShape();
        vertex(gameChar_x-7,gameChar_y-9);
        vertex(gameChar_x-9,gameChar_y-5);
        vertex(gameChar_x-13,gameChar_y-7);
        vertex(gameChar_x-11,gameChar_y-11);
        endShape(CLOSE);
        ellipse(gameChar_x-13.5,gameChar_y-10,3.5,3.5);

        //sleeve
        fill(255);
        arc(gameChar_x,gameChar_y-34,5,10,PI,TWO_PI,PIE);

        //arm
        fill(255,253,77);
        rect(gameChar_x-1.5,gameChar_y-34,3,8);
        ellipse(gameChar_x,gameChar_y-27,3,3);

        //sponge
        fill(163, 157, 129);
        noStroke();
        ellipse(gameChar_x-3,gameChar_y-58,7,6);
        ellipse(gameChar_x+4,gameChar_y-54,3,3);
        ellipse(gameChar_x-3,gameChar_y-47,7,6);
        ellipse(gameChar_x+4,gameChar_y-43,3,3);
        

	}
    //code for when character walking right
	else if(isRight)
	{
        //eye
    
        fill(255);
        stroke(0);
        strokeWeight(0.5);
        ellipse(gameChar_x+10,gameChar_y-58,5,8);
        fill(0,153,255);
        ellipse(gameChar_x+10,gameChar_y-58,3,3);
        fill(0);
        ellipse(gameChar_x+10,gameChar_y-58,1.5,1.5);


        //body
        fill(255,253,77);
        stroke(0);
        strokeWeight(0.5);  

        //nose
        ellipse(gameChar_x+11,gameChar_y-50,10,3);

        rect(gameChar_x-10,gameChar_y-67,20,30);



        //pants
        fill(115,80,50);
        rect(gameChar_x-10,gameChar_y-32,20,8);
        beginShape();
        vertex(gameChar_x+2,gameChar_y-24);
        vertex(gameChar_x+5,gameChar_y-24);
        vertex(gameChar_x+7,gameChar_y-21);
        vertex(gameChar_x+2,gameChar_y-21);
        endShape(CLOSE);
        rect(gameChar_x-4,gameChar_y-24,6,3);
        fill(0);
        rect(gameChar_x-3,gameChar_y-30,6,2);

        //shirt
        fill(255);
        stroke(0);
        strokeWeight(0.5);
        rect(gameChar_x-10,gameChar_y-37,20,5);


        //legs
        fill(255,253,77);
        rect(gameChar_x-3,gameChar_y-21,4,8);
        beginShape();
        vertex(gameChar_x+2,gameChar_y-21);
        vertex(gameChar_x+5,gameChar_y-13);
        vertex(gameChar_x+9,gameChar_y-15);
        vertex(gameChar_x+6,gameChar_y-21);
        endShape(CLOSE);



        //socks
        fill(255);
        rect(gameChar_x-3,gameChar_y-13,4,4);
        beginShape();
        vertex(gameChar_x+5,gameChar_y-13);
        vertex(gameChar_x+7,gameChar_y-9);
        vertex(gameChar_x+11,gameChar_y-11);
        vertex(gameChar_x+9,gameChar_y-15);
        endShape(CLOSE);

        //shoe
        fill(0);
        rect(gameChar_x-3,gameChar_y-9,4,4);
        ellipse(gameChar_x+2.5,gameChar_y-7,3.5,3.5);

        beginShape();
        vertex(gameChar_x+7,gameChar_y-9);
        vertex(gameChar_x+9,gameChar_y-5);
        vertex(gameChar_x+13,gameChar_y-7);
        vertex(gameChar_x+11,gameChar_y-11);
        endShape(CLOSE);
        ellipse(gameChar_x+13.5,gameChar_y-10,3.5,3.5);

        //sleeve
        fill(255);
        arc(gameChar_x,gameChar_y-34,5,10,PI,TWO_PI,PIE);

        //arm
        fill(255,253,77);
        rect(gameChar_x-1.5,gameChar_y-34,3,8);
        ellipse(gameChar_x,gameChar_y-27,3,3);


        fill(163, 157, 129);
        noStroke();
        ellipse(gameChar_x+3,gameChar_y-58,7,6);
        ellipse(gameChar_x-4,gameChar_y-54,3,3);
        ellipse(gameChar_x+3,gameChar_y-47,7,6);
        ellipse(gameChar_x-4,gameChar_y-43,3,3);

	}
    //code for when character jump facing forward or when character falls into canyon
	else if(isFalling || isPlummeting)
	{
        fill(255,253,77);
        stroke(0);
        strokeWeight(0.5);
        rect(gameChar_x-18,gameChar_y-62,36,40);

        beginShape();
        vertex(gameChar_x-5,gameChar_y-11);
        vertex(gameChar_x-9,gameChar_y-5);
        vertex(gameChar_x-12,gameChar_y-7);
        vertex(gameChar_x-8,gameChar_y-12);   
        endShape(CLOSE);

        beginShape();
        vertex(gameChar_x+6,gameChar_y-11);
        vertex(gameChar_x+10,gameChar_y-5);
        vertex(gameChar_x+13,gameChar_y-7);
        vertex(gameChar_x+9,gameChar_y-12);   
        endShape(CLOSE);

        fill(255);
        stroke(0);
        strokeWeight(0.5);

        ellipse(gameChar_x-6,gameChar_y-47,10,10);
        ellipse(gameChar_x+5,gameChar_y-47,10,10);
        rect(gameChar_x-17,gameChar_y-24,34,5);
        noStroke();
        fill(240);
        stroke(0);
        strokeWeight(0.5);

        beginShape();
        vertex(gameChar_x-9,gameChar_y-5);
        vertex(gameChar_x-12,gameChar_y-7);
        vertex(gameChar_x-14,gameChar_y-4);
        vertex(gameChar_x-11,gameChar_y-2);
        vertex(gameChar_x-9,gameChar_y-5);
        endShape();

        beginShape();
        vertex(gameChar_x+10,gameChar_y-5);
        vertex(gameChar_x+13,gameChar_y-7);
        vertex(gameChar_x+15,gameChar_y-4);
        vertex(gameChar_x+12,gameChar_y-2);
        vertex(gameChar_x+10,gameChar_y-5);
        endShape();



        fill(115,80,50);
        stroke(0);
        strokeWeight(0.5);
        rect(gameChar_x-17,gameChar_y-19,34,5);

        beginShape();
        vertex(gameChar_x-8,gameChar_y-14);
        vertex(gameChar_x-10,gameChar_y-12);
        vertex(gameChar_x-4,gameChar_y-10);
        vertex(gameChar_x-1,gameChar_y-14);
        endShape(CLOSE);

        beginShape();
        vertex(gameChar_x+2,gameChar_y-14);
        vertex(gameChar_x+5,gameChar_y-10);
        vertex(gameChar_x+11,gameChar_y-12);
        vertex(gameChar_x+9,gameChar_y-14);
        endShape(CLOSE);


        noStroke();
        fill(0);
        //left shoe
        beginShape();
        vertex(gameChar_x-11,gameChar_y-2);
        vertex(gameChar_x-13,gameChar_y+1);
        vertex(gameChar_x-16,gameChar_y-1);
        vertex(gameChar_x-14,gameChar_y-4);
        endShape(CLOSE);
        ellipse(gameChar_x-16,gameChar_y-3,3.5,3.5);

        //right shoe
        beginShape();
        vertex(gameChar_x+12,gameChar_y-2);
        vertex(gameChar_x+14,gameChar_y+1);
        vertex(gameChar_x+17,gameChar_y-1);
        vertex(gameChar_x+15,gameChar_y-4);
        endShape(CLOSE);
        ellipse(gameChar_x+17,gameChar_y-3,3.5,3.5);


        ellipse(gameChar_x+4,gameChar_y-47,1,1);
        ellipse(gameChar_x-5,gameChar_y-47,1,1);

        fill(0,153,255);


        ellipse(gameChar_x-5,gameChar_y-47,4,4);
        ellipse(gameChar_x+4,gameChar_y-47,4,4);

        fill(0);
        ellipse(gameChar_x+4,gameChar_y-47,2,2);
        ellipse(gameChar_x-5,gameChar_y-47,2,2);
        rect(gameChar_x-15,gameChar_y-18,4,2);
        rect(gameChar_x-9,gameChar_y-18,4,2);
        rect(gameChar_x+5,gameChar_y-18,4,2);
        rect(gameChar_x+11,gameChar_y-18,4,2);




        fill(255);
        stroke(0);
        strokeWeight(0.5);
        rect(gameChar_x-4,gameChar_y-35,3,3);
        rect(gameChar_x+1,gameChar_y-35,3,3);
        beginShape();
        vertex(gameChar_x-18,gameChar_y-32);
        vertex(gameChar_x-20,gameChar_y-27);
        vertex(gameChar_x-20,gameChar_y-22);
        vertex(gameChar_x-17,gameChar_y-22);
        endShape(CLOSE);

        beginShape();
        vertex(gameChar_x+18,gameChar_y-32);
        vertex(gameChar_x+20,gameChar_y-27);
        vertex(gameChar_x+20,gameChar_y-22);
        vertex(gameChar_x+17,gameChar_y-22);
        endShape(CLOSE);

        beginShape();
        vertex(gameChar_x-8,gameChar_y-24);
        vertex(gameChar_x-4,gameChar_y-22);
        vertex(gameChar_x-2,gameChar_y-24);
        endShape(CLOSE);

        beginShape();
        vertex(gameChar_x+1,gameChar_y-24);
        vertex(gameChar_x+3,gameChar_y-22);
        vertex(gameChar_x+7,gameChar_y-24);
        endShape(CLOSE);


        line(gameChar_x-12,gameChar_y-52, gameChar_x-10 ,gameChar_y-51);
        line(gameChar_x-7,gameChar_y-54, gameChar_x-7 , gameChar_y-52);
        line(gameChar_x-2.5,gameChar_y-53, gameChar_x-4 , gameChar_y-52);
        line(gameChar_x+1,gameChar_y-53, gameChar_x+3 , gameChar_y-52);
        line(gameChar_x+7, gameChar_y-54, gameChar_x+6, gameChar_y-52);
        line(gameChar_x+8,gameChar_y-51,gameChar_x+10,gameChar_y-52);


        fill(255,253,77);
        stroke(0);
        strokeWeight(0.5);
        rect(gameChar_x-2.5,gameChar_y-46,4,4);
        ellipse(gameChar_x,gameChar_y-37,25,5);
        beginShape();
        vertex(gameChar_x-19,gameChar_y-22);
        vertex(gameChar_x-17,gameChar_y-14);
        vertex(gameChar_x-17,gameChar_y-22);
        endShape(CLOSE);

        beginShape();
        vertex(gameChar_x+19,gameChar_y-22);
        vertex(gameChar_x+17,gameChar_y-14);
        vertex(gameChar_x+17,gameChar_y-22);
        endShape(CLOSE);



        noStroke();
        rect(gameChar_x-15,gameChar_y-41.9,30,5);

        stroke(0);
        strokeWeight(0.5);
        fill(255,0,0);
        beginShape();
        vertex(gameChar_x-2,gameChar_y-24);
        vertex(gameChar_x-0.5,gameChar_y-21);
        vertex(gameChar_x+0.5,gameChar_y-21);
        vertex(gameChar_x+2,gameChar_y-24);
        endShape(CLOSE);

        beginShape();
        vertex(gameChar_x-0.5,gameChar_y-21);
        vertex(gameChar_x-2,gameChar_y-19);
        vertex(gameChar_x,gameChar_y-15);
        vertex(gameChar_x+2,gameChar_y-19);
        vertex(gameChar_x+0.5,gameChar_y-21);

        endShape(CLOSE);

        //smile
        stroke(0);
        strokeWeight(0.5);
        fill(82, 45, 50);
        arc(gameChar_x,gameChar_y-37,25,15,TWO_PI,PI, PIE);
        fill(255);
        rect(gameChar_x-4,gameChar_y-37,3,3);
        rect(gameChar_x+1,gameChar_y-37,3,3);
        fill(222, 129, 140);
        arc(gameChar_x,gameChar_y-30,10,4,PI,TWO_PI,PIE);

        //sponge
        fill(163, 157, 129);
        noStroke();
        ellipse(gameChar_x-14,gameChar_y-58,4,4);
        ellipse(gameChar_x-14,gameChar_y-54,2,2);
        ellipse(gameChar_x+14,gameChar_y-58,3,3);
        ellipse(gameChar_x+14,gameChar_y-27,2,2);
        ellipse(gameChar_x+14,gameChar_y-31,4,4);
        ellipse(gameChar_x-14,gameChar_y-32,2,2);
        ellipse(gameChar_x-14,gameChar_y-28,4,4);

	}
    //code for when character standing still facing forward
	else
	{
		// add your standing front facing code
        fill(255,253,77);
        stroke(0);
        strokeWeight(0.5);
        rect(gameChar_x - 18, gameChar_y - 62,36,40);
        rect(gameChar_x + 3,gameChar_y - 11,3,7);
        rect(gameChar_x - 5, gameChar_y - 11,3,7);

        fill(255);
        stroke(0);
        strokeWeight(0.5);

        ellipse(gameChar_x - 6,gameChar_y-47,10,10);
        ellipse(gameChar_x + 5,gameChar_y-47,10,10);
        rect(gameChar_x-17,gameChar_y-24,34,5);
        noStroke();
        fill(240);
        stroke(0);
        strokeWeight(0.5);
        rect(gameChar_x+3,gameChar_y-4,3,3);
        rect(gameChar_x-5,gameChar_y-4,3,3);



        fill(115,80,50);
        stroke(0);
        strokeWeight(0.5);
        rect(gameChar_x-17,gameChar_y-19,34,5);
        rect(gameChar_x-6,gameChar_y-14,5,3);
        rect(gameChar_x+2,gameChar_y-14,5,3);

        noStroke();
        fill(0);
        rect(gameChar_x-5,gameChar_y-1,3,3);
        ellipse(gameChar_x-6.2,gameChar_y+0.3,3.5,3.5);
        rect(gameChar_x+3,gameChar_y-1,3,3);
        ellipse(gameChar_x+7,gameChar_y+0.3,3.5,3.5);
        ellipse(gameChar_x+4,gameChar_y-47,1,1);
        ellipse(gameChar_x-5,gameChar_y-47,1,1);

        fill(0,153,255);


        ellipse(gameChar_x-5,gameChar_y-47,4,4);
        ellipse(gameChar_x+4,gameChar_y-47,4,4);

        fill(0);
        ellipse(gameChar_x+4,gameChar_y-47,2,2);
        ellipse(gameChar_x-5,gameChar_y-47,2,2);
        rect(gameChar_x-8,gameChar_y-18,4,2);
        rect(gameChar_x-14,gameChar_y-18,4,2);
        rect(gameChar_x+5,gameChar_y-18,4,2);
        rect(gameChar_x+11,gameChar_y-18,4,2);




        fill(255);
        stroke(0);
        strokeWeight(0.5);
        rect(gameChar_x-4,gameChar_y-35,3,3);
        rect(gameChar_x+1,gameChar_y-35,3,3);
        beginShape();
        vertex(gameChar_x-18,gameChar_y-32);
        vertex(gameChar_x-20,gameChar_y-27);
        vertex(gameChar_x-20,gameChar_y-22);
        vertex(gameChar_x-17,gameChar_y-22);
        endShape(CLOSE);

        beginShape();
        vertex(gameChar_x+18,gameChar_y-32);
        vertex(gameChar_x+20,gameChar_y-27);
        vertex(gameChar_x+20,gameChar_y-22);
        vertex(gameChar_x+17,gameChar_y-22);
        endShape(CLOSE);

        beginShape();
        vertex(gameChar_x-8,gameChar_y-24);
        vertex(gameChar_x-4,gameChar_y-22);
        vertex(gameChar_x-2,gameChar_y-24);
        endShape(CLOSE);

        beginShape();
        vertex(gameChar_x+1,gameChar_y-24);
        vertex(gameChar_x+3,gameChar_y-22);
        vertex(gameChar_x+7,gameChar_y-24);
        endShape(CLOSE);


        line(gameChar_x-12,gameChar_y-52, gameChar_x-10,gameChar_y-51);
        line(gameChar_x-7,gameChar_y-54, gameChar_x-7, gameChar_y-52);
        line(gameChar_x-2.5,gameChar_y-53, gameChar_x-4, gameChar_y-52);
        line(gameChar_x+1,gameChar_y-53, gameChar_x+3, gameChar_y-52);
        line(gameChar_x+6, gameChar_y-54, gameChar_x+6, gameChar_y-52);
        line(gameChar_x+8,gameChar_y-51,gameChar_x+10,gameChar_y-52);


        fill(255,253,77);
        stroke(0);
        strokeWeight(0.5);
        rect(gameChar_x-2.5,gameChar_y-46,4,4);
        ellipse(gameChar_x,gameChar_y-37,25,5);
        beginShape();
        vertex(gameChar_x-19,gameChar_y-22);
        vertex(gameChar_x-17,gameChar_y-14);
        vertex(gameChar_x-17,gameChar_y-22);
        endShape(CLOSE);

        beginShape();
        vertex(gameChar_x+19,gameChar_y-22);
        vertex(gameChar_x+17,gameChar_y-14);
        vertex(gameChar_x+17,gameChar_y-22);
        endShape(CLOSE);



        noStroke();
        rect(gameChar_x-15,gameChar_y-41.9,30,5);

        stroke(0);
        strokeWeight(0.5);
        fill(255,0,0);
        beginShape();
        vertex(gameChar_x-2,gameChar_y-24);
        vertex(gameChar_x-0.5,gameChar_y-21);
        vertex(gameChar_x+0.5,gameChar_y-21);
        vertex(gameChar_x+2,gameChar_y-24);
        endShape(CLOSE);

        beginShape();
        vertex(gameChar_x-0.5,gameChar_y-21);
        vertex(gameChar_x-2,gameChar_y-19);
        vertex(gameChar_x,gameChar_y-15);
        vertex(gameChar_x+2,gameChar_y-19);
        vertex(gameChar_x+0.5,gameChar_y-21);

        endShape(CLOSE);


        //sponge
        fill(163, 157, 129);
        noStroke();
        ellipse(gameChar_x-14,gameChar_y-58,4,4);
        ellipse(gameChar_x-14,gameChar_y-54,2,2);
        ellipse(gameChar_x+14,gameChar_y-58,3,3);
        ellipse(gameChar_x+14,gameChar_y-27,2,2);
        ellipse(gameChar_x+14,gameChar_y-31,4,4);
        ellipse(gameChar_x-14,gameChar_y-32,2,2);
        ellipse(gameChar_x-14,gameChar_y-28,4,4);
        
        
	}
    
    //check if player reached flagpole
    renderFlagpole();
    
    //check if game is over if number of lives left is less than 1
    if (lives < 1){
        fill(0);
        textSize(30);
        //show game over message to screen
        text("Game Over. Press space to continue. ", gameChar_x-200, height/2);
        //set game over variable to true
        isDead = true;
        

    }
    
    //check if flagpole is reached
    if(flagpole.isReached){
        fill(0);
        textSize(30);
        //show level complete message to screen when flagpole reached
        text("Level complete. Press space to continue. ", gameChar_x-200, height/2)
        
        
    }
    
    //iterate through enemies position list
    for(var i = 0; i < enemies.length; i++)
        {
            //draw the enemies
            enemies[i].draw();
            //check if player in contact with enemy
            var isContact = enemies[i].checkContact(gameChar_world_x,gameChar_y);
            if (isContact == true)
                {
                    //check if player still have lives left when in contact with enemy
                    if(lives > 0)
                    {
                        //play hit sound when in contact with enemy
                        hitSound.play();
                        //player loses one life
                        lives -= 1;
                        //start the game again
                        startGame();
                        break;
                    }
                }
        }

     
    pop();
    
    //draw lives
    drawHearts();
    
    fill(0);
    noStroke();
    //show the game score
    text("score: " + game_score, 30, 60);
    //show number of lives left
    text("lives: ", 30, 30);

	///////////INTERACTION CODE//////////
    
    //code for player moving left
    if (isLeft == true)
    {
        gameChar_x -= 3;
    }
        
    //code for player moving right
    else if (isRight == true)
    {
        gameChar_x += 3;
    }
        
    //code for player jumping 
    if(gameChar_y < floorPos_y)
    {   
        var isContact = false;
        //iterate through list of platform positions
        for(var i = 0; i < platforms.length; i++)
        {
            //check if player is jumping onto the platform
            if(platforms[i].checkContact(gameChar_world_x, gameChar_y)== true)
            {
                isContact = true;
                break;
            }
        }
        
        if(isContact == false)
            {
                gameChar_y += 3;
                isFalling = true;
            }
        
    }
    
    //code for when player lands on the ground
    else if(gameChar_y == floorPos_y)
    {
        isFalling = false;
    }
    
 
    //code for when player falls into canyon
    if (isPlummeting == true)
    {
        //set player unable to move left or right
        gameChar_y += 5;
        isLeft = false;
        isRight = false;
        checkPlayerDie();
        return;
    }
    //if player did not reach flagpole yet, keep checking if flagpole reached
    if(flagpole.isReached == false){
        checkFlagpole();
    }
    
    //if game is not over, keep checking if game is over
    if(isDead == false){
        checkPlayerDie();
    }
    
    
    //Update real position of gameChar for collision detection
    gameChar_world_x = gameChar_x - scrollPos;
    

}


function keyPressed()
{
	// if statements to control the animation of the character when
	// keys are pressed.
    
	//code for when game not over
    if (isDead == false)
    {
        //code for when left arrow key is pressed
        if (keyCode == 37)
        {
            console.log("left arrow");
            isLeft = true;
        }
        //code for when right arrow key is pressed
        else if (keyCode == 39)
        {
            console.log("right arrow");
            isRight = true;
        }
        //code for when up arrow key is pressed
        else if (keyCode == 38)
        {
            if((gameChar_x == floorPos_y)|| (isFalling == false && isPlummeting == false)){
                gameChar_y -= 105;
                //play jump sound when up arrow key is pressed
                jumpSound.play();
            }
        } 
    }
        
    //code for when left space bar is pressed only if game over or flagpole reached
    if((isDead == true || flagpole.isReached == true) && keyCode == 32){
        //start game again
        startGame();
        //set starting number of lives to 3
        lives = 3;
        //set starting game score to 0
        game_score = 0;
        
    
        
    };
    
    
}

function keyReleased()
{
	// if statements to control the animation of the character when keys are released.
    //code for when left arrow key released
    if (keyCode == 37)
    {
        isLeft = false;
    }
    //code for when right arrow key released
    else if (keyCode == 39)
    {
        isRight = false;
    }
    //code for when up arrow key released
    else if (keyCode == 38)
    {
        isFalling = false;
    }
}

//function to draw clouds
function drawClouds(){
    for(var i = 0; i < clouds.length; i++){
       
        fill(255,255,255);
        //draw three circles that overlap to form a cloud
        ellipse(clouds[i].x_pos+200,clouds[i].y_pos+100,80,80);
        ellipse(clouds[i].x_pos+160,clouds[i].y_pos+100,60,60);
        ellipse(clouds[i].x_pos+240,clouds[i].y_pos+100,60,60);
        
    }
    
}

//function to draw mountains
function drawMountains(){
    for (var i = 0; i < mountain_x.length; i++){
         //mountain 
        fill(160,160,160);
        triangle(mountain_x[i]+300,mountain_y+432,mountain_x[i]+450,mountain_y+180,mountain_x[i]+600,mountain_y+432);
        fill(128,128,128);
        triangle(mountain_x[i]+270,mountain_y+432,mountain_x[i]+370,mountain_y+250,mountain_x[i]+500,mountain_y+432);
        fill(140,140,140);
        triangle(mountain_x[i]+440,mountain_y+432,mountain_x[i]+540,mountain_y+220,mountain_x[i]+660,mountain_y+432);
        //snow
        fill(255);
        triangle(mountain_x[i]+429,mountain_y+215,mountain_x[i]+450,mountain_y+180,mountain_x[i]+471,mountain_y+215);
        triangle(mountain_x[i]+354,mountain_y+280,mountain_x[i]+370,mountain_y+250,mountain_x[i]+391,mountain_y+280);
        triangle(mountain_x[i]+526,mountain_y+250,mountain_x[i]+540,mountain_y+220,mountain_x[i]+557,mountain_y+250);

        
    }
}

//function to draw trees
function drawTrees(){
    for(var i = 0; i < trees_x.length; i++){
         
        //tree
        fill(120,100,40);
        rect(trees_x[i]+200,treePos_y-6,45,150);

        //branches 
        fill(0,155,0);
        triangle(trees_x[i]+140, treePos_y+118, trees_x[i]+220, treePos_y+18, trees_x[i]+300, treePos_y+118);
        triangle(trees_x[i]+140, treePos_y+53, trees_x[i]+220, treePos_y-50, trees_x[i]+300, treePos_y+53);
        fill(150, 0, 0);
        ellipse(trees_x[i]+190, treePos_y-2, 10, 10);
        ellipse(trees_x[i]+275, treePos_y+28, 10, 10);
        ellipse(trees_x[i]+190, treePos_y+58, 10, 10);
        ellipse(trees_x[i]+270, treePos_y+88, 10, 10);
        fill(0,250,0);
        ellipse(trees_x[i]+215, treePos_y+8, 10, 10);
        ellipse(trees_x[i]+250, treePos_y+38, 10, 10);
        ellipse(trees_x[i]+210, treePos_y+68, 10, 10);
        ellipse(trees_x[i]+230, treePos_y+98, 10, 10);

        fill(0,0,255);
        ellipse(trees_x[i]+245, treePos_y+18, 10, 10);
        ellipse(trees_x[i]+220, treePos_y+48, 10, 10);
        ellipse(trees_x[i]+240, treePos_y+78, 10, 10);
        ellipse(trees_x[i]+190, treePos_y+108, 10, 10);

        fill(255,255,0);
        triangle(trees_x[i]+210, treePos_y-62, trees_x[i]+220, treePos_y-47, trees_x[i]+230, treePos_y-62);
        triangle(trees_x[i]+210, treePos_y-52, trees_x[i]+220, treePos_y-67, trees_x[i]+230, treePos_y-52);

    }
   
}
//function to squidward house 
function drawSquidwardHouse(){
    //ears
    fill(15, 55, 90);
    rect(squidwardHouse_x-5,squidwardHouse_y-150,30,70);
    rect(squidwardHouse_x+125,squidwardHouse_y-150,30,70);
    
    //body
    fill(8, 74, 126);
    beginShape();
    vertex(squidwardHouse_x,squidwardHouse_y);
    vertex(squidwardHouse_x+30,squidwardHouse_y-225);
    vertex(squidwardHouse_x+120, squidwardHouse_y-225);
    vertex(squidwardHouse_x+150, squidwardHouse_y);
    endShape();
    //eyebrow
    fill(15, 55, 90);
    rect(squidwardHouse_x+40,squidwardHouse_y-165,70,15);
    //nose
    beginShape();
    vertex(squidwardHouse_x+72.5,squidwardHouse_y-165);
    vertex(squidwardHouse_x+62.5,squidwardHouse_y-80);
    vertex(squidwardHouse_x+87.5,squidwardHouse_y-80);
    vertex(squidwardHouse_x+77.5,squidwardHouse_y-165);
    endShape();
    //eyes
    fill(158, 175, 201);
    ellipse(squidwardHouse_x+54,squidwardHouse_y-136,25,25);
    ellipse(squidwardHouse_x+96,squidwardHouse_y-136,25,25);
    fill(7, 198, 226);
    ellipse(squidwardHouse_x+54,squidwardHouse_y-136,16,16);
    ellipse(squidwardHouse_x+96,squidwardHouse_y-136,16,16);
    //door
    fill(110, 82, 43);
    arc(squidwardHouse_x+75,squidwardHouse_y,50,140,PI,TWO_PI,PIE);
    fill(66, 49, 21);
    rect(squidwardHouse_x+57,squidwardHouse_y-49,1,49);
    rect(squidwardHouse_x+67,squidwardHouse_y-67,1,67);
    rect(squidwardHouse_x+77,squidwardHouse_y-70,1,70);
    rect(squidwardHouse_x+87,squidwardHouse_y-61,1,61);
    rect(squidwardHouse_x+97,squidwardHouse_y-28,1,28);

}

//function to draw spongebob house
function drawSpongebobHouse(){
    
    //leaves
    stroke(0);
    strokeWeight(0.5);
    fill(63, 153, 0);
    ellipse(spongebobHouse_x+75,spongebobHouse_y-185,60,120);
    fill(104, 202, 41);
    arc(spongebobHouse_x+65,spongebobHouse_y-185,90,90,PI+350,TWO_PI+350,PIE);
    arc(spongebobHouse_x+85,spongebobHouse_y-185,90,90,TWO_PI+250,PI+250,PIE);
    fill(165, 217, 29);
    arc(spongebobHouse_x+50,spongebobHouse_y-175,70,70,PI+400,TWO_PI+400,PIE);
    arc(spongebobHouse_x+100,spongebobHouse_y-175,70,70,TWO_PI+200,PI+200,PIE);
    fill(45, 117, 9);
    arc(spongebobHouse_x+35,spongebobHouse_y-168,60,40,PI+500,TWO_PI+500,PIE);
    arc(spongebobHouse_x+115,spongebobHouse_y-168,60,40,TWO_PI+100,PI+100,PIE);
    noStroke();

    //body
    fill(248, 157, 14);
    ellipse(spongebobHouse_x+75,spongebobHouse_y-70,150,200);
    fill(219, 229, 195);
    rect(spongebobHouse_x,spongebobHouse_y,150,30);
    stroke(220, 99, 30);
    strokeWeight(2);
    line(spongebobHouse_x+22,spongebobHouse_y, spongebobHouse_x+146, spongebobHouse_y-100);
    line(spongebobHouse_x+6,spongebobHouse_y-30, spongebobHouse_x+136, spongebobHouse_y-130);
    line(spongebobHouse_x,spongebobHouse_y-60, spongebobHouse_x+120, spongebobHouse_y-150);
    line(spongebobHouse_x+3,spongebobHouse_y-95, spongebobHouse_x+98, spongebobHouse_y-165);
    line(spongebobHouse_x+70,spongebobHouse_y-1, spongebobHouse_x+149, spongebobHouse_y-65);
    line(spongebobHouse_x+110,spongebobHouse_y-1, spongebobHouse_x+143, spongebobHouse_y-30);
    line(spongebobHouse_x+15,spongebobHouse_y-130, spongebobHouse_x+68, spongebobHouse_y-168);
    line(spongebobHouse_x+6,spongebobHouse_y-110, spongebobHouse_x+128, spongebobHouse_y-1);
    line(spongebobHouse_x,spongebobHouse_y-77, spongebobHouse_x+90, spongebobHouse_y-1);
    line(spongebobHouse_x+4,spongebobHouse_y-40, spongebobHouse_x+50, spongebobHouse_y-1);
    line(spongebobHouse_x+20,spongebobHouse_y-137, spongebobHouse_x+142, spongebobHouse_y-28);
    line(spongebobHouse_x+38,spongebobHouse_y-155, spongebobHouse_x+150, spongebobHouse_y-60);
    line(spongebobHouse_x+60,spongebobHouse_y-167, spongebobHouse_x+147, spongebobHouse_y-97);
    //door
    noStroke();
    fill(129, 144, 177);
    arc(spongebobHouse_x+75,spongebobHouse_y,50,130,PI,TWO_PI,PIE);
    fill(70, 78, 101);
    arc(spongebobHouse_x+75,spongebobHouse_y,40,120,PI,TWO_PI,PIE);

    //window
    fill(100, 114, 151);
    ellipse(spongebobHouse_x+20,spongebobHouse_y-100,30,30);
    ellipse(spongebobHouse_x+120,spongebobHouse_y-35,30,30);
    fill(18, 235, 227);
    ellipse(spongebobHouse_x+20,spongebobHouse_y-100,20,20);
    ellipse(spongebobHouse_x+120,spongebobHouse_y-35,20,20);

    
    


}   

//function to draw patrick house
function drawPatrickHouse(){
    fill(220, 98, 97);
    arc(patrickHouse_x,patrickHouse_y,180,200,PI,TWO_PI,PIE);
    fill(239, 203, 129);
    rect(patrickHouse_x,patrickHouse_y-120,5,20);
    rect(patrickHouse_x-12,patrickHouse_y-120,30,5);
   
    
    

    
    
}
//function to draw collectable
function drawCollectable(t_collectable){
    if (!t_collectable.isFound)
    {
        fill(207, 168, 87);
        ellipse(t_collectable.x_pos-40,t_collectable.y_pos+323,t_collectable.size-3,t_collectable.size-8);
        fill(117, 69, 54);
        ellipse(t_collectable.x_pos-40,t_collectable.y_pos+318,t_collectable.size-3,t_collectable.size-8);
        fill(168, 255, 102);
        rect(t_collectable.x_pos-53,t_collectable.y_pos+312,t_collectable.size-3,t_collectable.size-18);
        fill(207, 168, 87);
        ellipse(t_collectable.x_pos-40,t_collectable.y_pos+310,t_collectable.size-3,t_collectable.size-8);
        //seeds
        fill(255, 235, 171);
        ellipse(t_collectable.x_pos-45,t_collectable.y_pos+303,t_collectable.size-25,t_collectable.size-25);
        ellipse(t_collectable.x_pos-38,t_collectable.y_pos+302,t_collectable.size-25,t_collectable.size-25);
        ellipse(t_collectable.x_pos-40,t_collectable.y_pos+308,t_collectable.size-25,t_collectable.size-25);
        ellipse(t_collectable.x_pos-48,t_collectable.y_pos+309,t_collectable.size-25,t_collectable.size-25);
        ellipse(t_collectable.x_pos-30,t_collectable.y_pos+307,t_collectable.size-25,t_collectable.size-25);
        ellipse(t_collectable.x_pos-45,t_collectable.y_pos+305,t_collectable.size-25,t_collectable.size-25);
        ellipse(t_collectable.x_pos-35,t_collectable.y_pos+305,t_collectable.size-25,t_collectable.size-25);
	
    }
    
    
}

//function to draw canyons
function drawCanyon(t_canyon){
    
    fill(82, 32, 11);
    strokeWeight(1);
    beginShape();
    vertex(t_canyon.x_pos+210,t_canyon.width+332);
    vertex(t_canyon.x_pos+90,t_canyon.width+600);
    vertex(t_canyon.x_pos+330,t_canyon.width+600);
    vertex(t_canyon.x_pos+260,t_canyon.width+332);
    endShape();
    
    fill(115, 52, 25);
    beginShape();
    vertex(t_canyon.x_pos+200,t_canyon.width+332);
    vertex(t_canyon.x_pos+210,t_canyon.width+332);
    vertex(t_canyon.x_pos+100,t_canyon.width+600);
    vertex(t_canyon.x_pos+80,t_canyon.width+600);
    endShape();    
    beginShape();
    vertex(t_canyon.x_pos+260,t_canyon.width+332);
    vertex(t_canyon.x_pos+330,t_canyon.width+600);
    vertex(t_canyon.x_pos+340,t_canyon.width+600);
    vertex(t_canyon.x_pos+270,t_canyon.width+332);
    endShape();
    
}


//function to draw hearts to represent lives
function drawHearts(){
    for(var i = 0; i < lives; i++){
        fill(255,77,106);
        beginShape();
        vertex(heart[i],20);
        vertex(heart[i]+5,15);
        vertex(heart[i]+10,15);
        vertex(heart[i]+15,20);
        vertex(heart[i]+20,15);
        vertex(heart[i]+25,15);
        vertex(heart[i]+30,20);
        vertex(heart[i]+30,27.5);
        vertex(heart[i]+15,40);
        vertex(heart[i],27.5);
        vertex(heart[i],20);
        endShape();
    }
    
}

//function to check if collectable has been collected by player
function checkCollectable(t_collectable){
    if (dist(gameChar_x, gameChar_y, t_collectable.x_pos, t_collectable.y_pos+355)<t_collectable.size)
    {
        t_collectable.isFound = true;
        //play collectable sound when player manages to collect a collectable
        collectableSound.play();
        //increase game score by 1
        game_score += 1;
    }
    
}


//function to check if player fell into the canyon
function checkCanyon(t_canyon){
    if ((gameChar_x<(t_canyon.x_pos+270)) && (gameChar_x>(t_canyon.x_pos+200)) && (gameChar_y == floorPos_y))
    {
        isPlummeting = true;
        //play falling sound when player fall into canyon
        fallingSound.play();
        //player loses one life
        lives -= 1;
    };
    
    
}




//function to check if player reached flagpole and raise the flag when player reached flagpole
function renderFlagpole(){
    push();
    strokeWeight(5);
    stroke(100);
    //draw the pole
    line(flagpole.x_pos, floorPos_y, flagpole.x_pos, floorPos_y- 250);
    fill(255,77,106);
    noStroke();
    //if flagpole reached, raise the flag
    if(flagpole.isReached){
        image(flag, flagpole.x_pos,floorPos_y-250,150,100);
        isDead = true;
        
    }
    //if flagpole not reached yet, flag is on the ground
    else{
        image(flag, flagpole.x_pos,floorPos_y-100,150,100);
    }
    pop();
}


//function to check if flagpole is reached
function checkFlagpole(){
    var d = abs(gameChar_world_x - flagpole.x_pos);
    if(d < 15){
        flagpole.isReached = true;
        //play level complete sound when player reached flagpole
        levelCompleteSound.play();
    }
    
}

//function to check if player loses a life
function checkPlayerDie(){
    if(isPlummeting == true && gameChar_y > height){
        isPlummeting = false;
        gameChar_x = width/2;
        gameChar_y = floorPos_y;
        
    }
    
    
}

//function to draw platforms based on positions list of platforms
function createPlatforms(x, y, length){
    var p = {
        x: x,
        y: y,
        length: length,
        draw: function(){
            stroke(0);
            strokeWeight(0.5);
            
            //2nd seaweed
            fill(186, 214, 112);
            beginShape();
            vertex(this.x+7, this.y);
            vertex(this.x+2, this.y-7);
            vertex(this.x+5, this.y-12);
            vertex(this.x+2, this.y-17);
            vertex(this.x+5, this.y-22);
            vertex(this.x+2, this.y-27);
            vertex(this.x+5, this.y-32);
            vertex(this.x+2, this.y-37);
            vertex(this.x+5, this.y-42);
            vertex(this.x+2, this.y-47);
            vertex(this.x+5, this.y-52);
            vertex(this.x+2, this.y-57);
            vertex(this.x+7, this.y-62);
            vertex(this.x+12, this.y-57);
            vertex(this.x+9, this.y-52);
            vertex(this.x+12, this.y-47);
            vertex(this.x+9, this.y-42);
            vertex(this.x+12, this.y-37);
            vertex(this.x+9, this.y-32);
            vertex(this.x+12, this.y-27);
            vertex(this.x+9, this.y-22);
            vertex(this.x+12, this.y-17);
            vertex(this.x+9, this.y-12);
            vertex(this.x+12, this.y-7);
            vertex(this.x+7, this.y);
            endShape();
            
            //5th seaweed
            fill(134, 182, 73);
            beginShape();
            vertex(this.x+28, this.y);
            vertex(this.x+23, this.y-7);
            vertex(this.x+26, this.y-12);
            vertex(this.x+26, this.y-17);
            vertex(this.x+24, this.y-22);
            vertex(this.x+26, this.y-27);
            vertex(this.x+24, this.y-32);
            vertex(this.x+26, this.y-37);
            vertex(this.x+24, this.y-42);
            vertex(this.x+26, this.y-47);
            vertex(this.x+24, this.y-52);
            vertex(this.x+26, this.y-57);
            vertex(this.x+28, this.y-62);
            vertex(this.x+33, this.y-57);
            vertex(this.x+30, this.y-52);
            vertex(this.x+33, this.y-47);
            vertex(this.x+30, this.y-42);
            vertex(this.x+33, this.y-37);
            vertex(this.x+30, this.y-32);
            vertex(this.x+33, this.y-27);
            vertex(this.x+30, this.y-22);
            vertex(this.x+33, this.y-17);
            vertex(this.x+30, this.y-12);
            vertex(this.x+33, this.y-7);
            vertex(this.x+28, this.y);
            endShape();
            
            //1st seaweed
            fill(134, 182, 73);
            beginShape();
            vertex(this.x, this.y);
            vertex(this.x-5, this.y-5);
            vertex(this.x-2, this.y-10);
            vertex(this.x-5, this.y-15);
            vertex(this.x-2, this.y-20);
            vertex(this.x-5, this.y-25);
            vertex(this.x-2, this.y-30);
            vertex(this.x-5, this.y-35);
            vertex(this.x, this.y-45);
            vertex(this.x+5, this.y-35);
            vertex(this.x+2, this.y-30);
            vertex(this.x+5, this.y-25);
            vertex(this.x+2, this.y-20);
            vertex(this.x+5, this.y-15);
            vertex(this.x+2, this.y-10);
            vertex(this.x+5, this.y-5);
            vertex(this.x, this.y);
            endShape();
            
            //3rd seaweed
            fill(103, 177, 80);
            beginShape();
            vertex(this.x+14, this.y);
            vertex(this.x+9, this.y-5);
            vertex(this.x+11, this.y-10);
            vertex(this.x+9, this.y-15);
            vertex(this.x+11, this.y-20);
            vertex(this.x+9, this.y-25);
            vertex(this.x+11, this.y-30);
            vertex(this.x+9, this.y-35);
            vertex(this.x+11, this.y-40);
            vertex(this.x+9, this.y-45);
            vertex(this.x+14, this.y-55);
            vertex(this.x+19, this.y-45);
            vertex(this.x+16, this.y-40);
            vertex(this.x+19, this.y-35);
            vertex(this.x+16, this.y-30);
            vertex(this.x+19, this.y-25);
            vertex(this.x+16, this.y-20);
            vertex(this.x+19, this.y-15);
            vertex(this.x+16, this.y-10);
            vertex(this.x+19, this.y-5);
            vertex(this.x+14, this.y);
            endShape();
            
            //4th seaweed
            fill(186, 214, 112);
            beginShape();
            vertex(this.x+21, this.y);
            vertex(this.x+16, this.y-5);
            vertex(this.x+18, this.y-10);
            vertex(this.x+16, this.y-15);
            vertex(this.x+18, this.y-20);
            vertex(this.x+16, this.y-25);
            vertex(this.x+18, this.y-30);
            vertex(this.x+21, this.y-35);
            vertex(this.x+24, this.y-30);
            vertex(this.x+26, this.y-25);
            vertex(this.x+24, this.y-20);
            vertex(this.x+26, this.y-15);
            vertex(this.x+24, this.y-10);
            vertex(this.x+26, this.y-5);
            vertex(this.x+21, this.y);
            endShape();
            
            //6th seaweed
            fill(103, 177, 80);
            beginShape();
            vertex(this.x+34, this.y);
            vertex(this.x+29, this.y-5);
            vertex(this.x+32, this.y-10);
            vertex(this.x+29, this.y-15);
            vertex(this.x+32, this.y-20);
            vertex(this.x+29, this.y-25);
            vertex(this.x+32, this.y-30);
            vertex(this.x+29, this.y-35);
            vertex(this.x+34, this.y-45);
            vertex(this.x+39, this.y-35);
            vertex(this.x+36, this.y-30);
            vertex(this.x+39, this.y-25);
            vertex(this.x+36, this.y-20);
            vertex(this.x+39, this.y-15);
            vertex(this.x+36, this.y-10);
            vertex(this.x+39, this.y-5);
            vertex(this.x+34, this.y);
            endShape();
            
            //rocks at base of seaweed
            fill(136, 103, 50);
            ellipse(this.x, this.y, this.length, 10);
            ellipse(this.x+30, this.y, this.length, 10);
            ellipse(this.x+15, this.y, this.length, 10);
        },
        //check if player is jumping onto platform
        checkContact: function(gc_x, gc_y)
        {
            if(gc_x > this.x - this.length && gc_x < this.x + 30 + this.length)
            {
                var d = this.y - gc_y;
                if(d >= 0 && d < 5)
                    {
                        isFalling = false;
                        isPlummeting = false;
                        return true;
                        
                    }
                
            }
            return false;
        }
    }
    return p;
}

//function to create and draw enemy
function Enemy(x,y,range)
{
    this.x = x;
    this.y = y;
    this.range = range;
    
    this.currentX = x;
    this.inc = 1;
    
    this.update = function()
    {
        this.currentX += this.inc;
        if(this.currentX >= this.x + this.range)
            {
                this.inc = -1;
            }
        else if(this.currentX < this.x)
            {
                this.inc = 1;
            }
    }
    this.draw = function()
    {
        this.update();
        //feelers
        noStroke();
        fill(17, 76, 5);
        beginShape();
        vertex(this.currentX-5,this.y-35);
        vertex(this.currentX-7,this.y-58);
        vertex(this.currentX-3,this.y-35);
        endShape();
        beginShape();
        vertex(this.currentX+5,this.y-35);
        vertex(this.currentX+7,this.y-58);
        vertex(this.currentX+3,this.y-35);
        endShape();
        fill(0);
        rect(this.currentX-6,this.y-40,3,1);
        rect(this.currentX-6.6,this.y-44.5,3,1);
        rect(this.currentX-7.1,this.y-49,3,1);
        rect(this.currentX-7.5,this.y-53,3,1);

        rect(this.currentX+3,this.y-40,3,1);
        rect(this.currentX+3.6,this.y-44.5,3,1);
        rect(this.currentX+4.1,this.y-49,3,1);
        rect(this.currentX+4.5,this.y-53,3,1);


        //body
        fill(111, 163, 150);
        ellipse(this.currentX,this.y-28,20,20);
        rect(this.currentX-10,this.y-28,20,25);
        ellipse(this.currentX,this.y-3,20,20);
        //legs
        ellipse(this.currentX-4,this.y+7,4,8);
        ellipse(this.currentX+4,this.y+7,4,8);
        //right hand
        beginShape();
        vertex(this.currentX+10,this.y-18);
        vertex(this.currentX+14,this.y-13);
        vertex(this.currentX+12,this.y-11);
        vertex(this.currentX+10,this.y-13);
        vertex(this.currentX+10,this.y-18);
        endShape();
        ellipse(this.currentX+13,this.y-12,3,3)
        //left hand
        beginShape();
        vertex(this.currentX-10,this.y-18);
        vertex(this.currentX-14,this.y-13);
        vertex(this.currentX-12,this.y-11);
        vertex(this.currentX-10,this.y-13);
        vertex(this.currentX-10,this.y-18);
        endShape();
        ellipse(this.currentX-13,this.y-12,3,3)
        //eye
        fill(242, 240, 153);
        ellipse(this.currentX,this.y-25,13,15);
        fill(255, 76, 44);
        ellipse(this.currentX,this.y-25,4,5);
        fill(255);
        ellipse(this.currentX,this.y-26,1,1);
        //eyebrow
        fill(0);
        rect(this.currentX-5,this.y-33.6,10,0.8);
        rect(this.currentX-4,this.y-32.8,8,0.8);
        rect(this.currentX-5,this.y-32,10,0.8);
        //mouth

        fill(140, 30, 3);
        arc(this.currentX,this.y-15,13,30,TWO_PI,PI, PIE);
        fill(255);
        stroke(0);
        strokeWeight(0.1);
        rect(this.currentX-6.4,this.y-15,2,2);
        rect(this.currentX-4.3,this.y-15,2,2);
        rect(this.currentX-2.2,this.y-15,2,2);
        rect(this.currentX-0.1,this.y-15,2,2);
        rect(this.currentX+2.0,this.y-15,2,2);
        rect(this.currentX+4.1,this.y-15,2,2);
        rect(this.currentX-6.2,this.y-15,2,2);
        noStroke();
        fill(243, 163, 138);
        arc(this.currentX,this.y-5,10,5,PI,TWO_PI, PIE);
        arc(this.currentX,this.y-5,10,9.7,TWO_PI, PI,PIE);
        stroke(0);
        strokeWeight(0.1);
        fill(255);
        arc(this.currentX,this.y-2.5,8.5,4.5,TWO_PI, PI,PIE);
        rect(this.currentX,this.y-2.5,2,2);
        rect(this.currentX-2,this.y-2.5,2,2);

        
    }
    //check if player in contact with enemy
    this.checkContact = function(gc_x,gc_y)
    {
        var d = dist(gc_x,gc_y, this.currentX, this.y);
        if(d < 28)
            {
                return true;

            }
        return false;
    }
}

//function to create and draw bubble particles
function Particle(x, y, xSpeed, ySpeed, size, color)
{
    this.x = x;
    this.y = y;
    this.xSpeed = xSpeed;
    this.ySpeed = ySpeed;
    this.size = size;
    this.color = color;
    this.age = 0;
    
    this.drawParticle = function()
    {
        fill(this.color)
        ellipse(this.x, this.y, this.size)
    }
    
    this.updateParticle = function()
    {
        this.x += this.xSpeed;
        this.y += this.ySpeed;
        this.age++;
    }
}


//function to create emitter to create bubbles
function Emitter(x, y, xSpeed, ySpeed, size, color)
{
    this.x = x;
    this.y = y;
    this.xSpeed = xSpeed;
    this.ySpeed = ySpeed;
    this.size = size;
    this.color = color;
    
    this.startParticles = 0;
    this.lifetime = 0;
    
    this.particles = [];
    
    this.addParticle = function()
    {
        var p = new Particle(random(this.x - 10,this.x + 10), 
                             random(this.y - 10, this.y + 10), 
                             random(this.xSpeed-1, this.xSpeed + 1), 
                             random(this.ySpeed - 1, this.ySpeed + 1), 
                             random(this.size - 4, this.size + 4), 
                             this.color);
        return p;
    }
    
    this.startEmitter = function(startParticles, lifetime)
    {
        this.startParticles = startParticles;
        this.lifetime = lifetime;
        
        //start emitter with initial particles
        for(var i = 0; i < startParticles; i++)
            {
                var p = new Particle(random(this.x - 10,this.x + 10), 
                                     random(this.y - 10, this.y + 10), 
                                     random(this.xSpeed-1, this.xSpeed + 1), 
                                     random(this.ySpeed - 1, this.ySpeed + 1), 
                                     random(this.size - 4, this.size + 4), 
                                     this.color);
                this.particles.push(this.addParticle());
                
            }
    }
    
    this.updateParticles = function()
    {
        //iterate through particles and draw to screen
        var deadParticles = 0;
        for(var i = this.particles.length-1; i >= 0; i--)
            {
                this.particles[i].drawParticle();
                this.particles[i].updateParticle();
                if(this.particles[i].age > random(0, this.lifetime))
                    {
                        this.particles.splice(i, 1);
                        deadParticles++
                        
                    }
            }
        if(deadParticles > 0)
            {
                for(var i = 0; i < deadParticles; i++)
                    {
                        this.particles.push(this.addParticle());
                        this.particles.push(this.addParticle());
                        this.particles.push(this.addParticle());
                    }
            }
    }
    

}


